package com.cg.app.dao;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.app.model.Customer;
import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;
@Repository
@Primary
public interface CapStoreDao extends JpaRepository<PromoGenerator, String> {
	@Query("select c from Customer c")
	public List<Customer> getCustomers();
	
	@Query("select c from Product c")
	public List<Product> getProducts();
}