package com.cg.app.controllers;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;
import com.cg.app.services.CapStoreService;
import com.cg.app.services.CapStoreServiceImpl;


@RestController
@RequestMapping("/store")
public class CapStoreController {
	@Autowired CapStoreService cap;
	//@Autowired CouponGenerator c;
	
	 
	@PostMapping(value="/create" )
	public ResponseEntity<String> create() {
		//System.out.println("hvghj");
	cap.createPromo();	
		return new ResponseEntity<String>("Promos Generated",HttpStatus.CREATED);
	}
	
	
	@PostMapping(value="/createproduct", consumes= {"application/json","application/xml"})
	public ResponseEntity<String> createproduct(@RequestBody Product p){
		
		cap.createProduct(p);

		return new ResponseEntity<String>("product Created",HttpStatus.CREATED);
	}
	
	
	
	@PostMapping(value="/send/{email}" )
	public ResponseEntity<List<String>> send(@PathVariable("email") String email) {
		//System.out.println("hvghj");
		
		List<String> list = cap.sendPromos(email);
		return new ResponseEntity<List<String>>(list,HttpStatus.CREATED);
	
	}
	
	@PostMapping(value="/sendpro/{email}")
	public ResponseEntity<List<String>> sendpro(@PathVariable("email") String email){
		List<String> plist= cap.sendProduct(email);
		return new ResponseEntity<List<String>>(plist,HttpStatus.CREATED);
		
		
	}
	
	
}
