package com.cg.app.services;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.dao.CapStoreDao;
import com.cg.app.dao.CustomerDao;
import com.cg.app.dao.ProductDao;
import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;
@Service
@Transactional
public class CapStoreServiceImpl implements CapStoreService {
@Autowired private CapStoreDao dao;
@Autowired private CustomerDao dao1;
@Autowired private ProductDao dao2;
	

		
	
	@Transactional
	public void generatePromo(PromoGenerator promo) {
		dao.save(promo);
		
	}




	
	public void createPromo() {
		char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new SecureRandom();
        for (int i = 0; i < 8; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String a = sb.toString();
        System.out.println(a);
        PromoGenerator cap1=new PromoGenerator();
     
        
        	 cap1.setPromocode(a);
             cap1.setDescription("50% of on all TOP BRANDS");
             cap1.setAmount(50d);
          LocalDateTime ld=LocalDateTime.now();
          LocalDateTime nd = ld.plusMonths(2);
         
          String expdate = nd.format(DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss"));
          cap1.setDate(expdate);
          System.out.println(expdate);
             generatePromo(cap1);	
	}
	@Override
	@Transactional
	public List<PromoGenerator> getPromos()
	{
		List<PromoGenerator> clist = dao.findAll();
		return clist;
	}
	
	
	
	
	@Transactional
	@Override
	public List<String> sendPromos(String email)
	{
		List<PromoGenerator> list = getPromos();
		List<String> sentList = new ArrayList<String>();
		int i=1;
//		System.out.println(list.get(0).getDescription());
		for(PromoGenerator l : list)
		{
			sentList.add((i++)+" "+l.getPromocode()+" "+l.getDescription()+" of Rs."+l.getAmount() +"sent to "+email);
		}
		return sentList;
	}




	@Transactional
	@Override
	public List<String> sendProduct(String email) {
		// TODO Auto-generated method stub
		List<Product> plist= getProducts();
		
		List<String> sentList1 = new ArrayList<String>();
		int i=2;
		for(Product p : plist)
		{
			sentList1.add((i=2)+" "+p.getProductid()+" "+p.getProductdetails()+" for Rs."+p.getPrice()+" "+"sent to "+email);
			//add((product)
		}
		
		return sentList1;
	}





	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		List<Product> plist = dao2.findAll();
		System.out.println(plist);
		return plist;
	}





	@Override
	public void createProduct(Product p) {
		// TODO Auto-generated method stub
		dao2.save(p);
		
	}

	

	
}