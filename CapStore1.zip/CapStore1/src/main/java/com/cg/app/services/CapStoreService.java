package com.cg.app.services;



import java.util.List;

import com.cg.app.model.Customer;
import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;

public interface CapStoreService {
 void generatePromo( PromoGenerator promo);
	void createPromo();
	List<PromoGenerator> getPromos();
	List<String> sendPromos(String email);
	void createProduct(Product p);
	List<Product> getProducts();
	List<String> sendProduct(String email);
	

}
