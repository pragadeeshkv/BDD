package com.cg.app.model;

import javax.persistence.*;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="product")
@XmlRootElement
public class Product {
	@Id
	@Column(name="productid")
	private Integer productid;
	
	@Column(name="productdetails")
	private String productdetails;
	
	@Column(name="price")
	private Double price;

	public Integer getProductid() {
		return productid;
	}

	public void setProductid(Integer productid) {
		this.productid = productid;
	}

	public String getProductdetails() {
		return productdetails;
	}

	public void setProductdetails(String productdetails) {
		this.productdetails = productdetails;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productdetails=" + productdetails + ", price=" + price + "]";
	}
	
	
	
	
	
	

}
