package com.capgemini.EmployeeManagement177541.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.EmployeeManagement177541.bean.Employee;
import com.capgemini.EmployeeManagement177541.dao.EmployeeDao;
import com.capgemini.EmployeeManagement177541.exception.EmployeeApplicationException;



/*
 * Localhost url used for performing Database operations
 * URL : http://localhost:8087/
 */
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired EmployeeDao emp_dao;

	@Override
	public List<Employee> viewAllEmps() {
		// TODO Auto-generated method stub
		return emp_dao.findAll();
	}
	
	@Override
	@Transactional(readOnly=true)
	public Employee viewById(String id) {
		
		Optional<Employee> temp = emp_dao.findById(id);
		/*
		 * checking whether the Employee record exits or not
		 * if doesn't exist,throwing an Exception
		 */
		if(!temp.isPresent()) {
			throw new EmployeeApplicationException(id+" Record Not Found....!");
		}
		
		
		return temp.get();
	}
	
	
}
