package com.capgemini.EmployeeManagement177541.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.EmployeeManagement177541.bean.Employee;
import com.capgemini.EmployeeManagement177541.services.EmployeeService;


/*
* Localhost url used for performing Database operations
* URL : http://localhost:8087/
*/
@RestController
/*
 * http://localhost:8087/ database url
 */

/*ResponseEntity<String>
 * Response Entity is used for displaying Message to the End User
 */
@RequestMapping("/")
public class EmployeeController {
	
	@Autowired private EmployeeService service;
	
	
	
	 @GetMapping(value="/send")
	 public ResponseEntity<String> sendMsg(@RequestParam("id") String msg,@RequestParam("custid") String custid){
		Employee emp=service.viewById(custid);
		return new ResponseEntity<String>(send(emp.getEmail(),msg),HttpStatus.CREATED);	 			 
	}
	 
	 
	 

	
	 public String send(String emp,String msg){
		 
			return msg+" send to "+emp;
						
		 }
	
}
