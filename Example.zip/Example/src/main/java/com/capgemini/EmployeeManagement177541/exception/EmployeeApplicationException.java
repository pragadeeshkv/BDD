package com.capgemini.EmployeeManagement177541.exception;

/**
 * Creating an UserDefined Runtime Exception 
 * @author vasairam
 *
 */

public class EmployeeApplicationException extends RuntimeException {

	public EmployeeApplicationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeApplicationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}