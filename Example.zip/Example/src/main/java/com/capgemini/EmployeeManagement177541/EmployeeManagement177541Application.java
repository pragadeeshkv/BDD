package com.capgemini.EmployeeManagement177541;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagement177541Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagement177541Application.class, args);
	}

}
