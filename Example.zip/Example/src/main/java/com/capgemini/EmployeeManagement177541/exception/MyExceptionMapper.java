

package com.capgemini.EmployeeManagement177541.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Creating a controller for EmployeeApplicationException clas,
 * if any method throws EmployeeApplicationException the error message is shown to the user using this controller
 * @author vasairam
 *
 */
@ControllerAdvice
public class MyExceptionMapper {
	
	@ExceptionHandler(value=EmployeeApplicationException.class)
	@ResponseBody
	protected ResponseEntity<String> handleError(EmployeeApplicationException ex,HttpServletRequest req){
		
		
		String message = ex.getMessage();
		System.out.println("Caught Expression "+message);
		String url = req.getRequestURI().toString();
		System.out.println("Error at "+url);
		return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
		
	}

}
