package com.capgemini.EmployeeManagement177541.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.EmployeeManagement177541.bean.Employee;


/**
 * Extending the JpaRepository predefined Class
 * JpaRepository class contains predefined methods for performing CURD operations
 * @author vasairam
 *
 */
@Repository
public interface EmployeeDao extends JpaRepository<Employee, String> {

}
