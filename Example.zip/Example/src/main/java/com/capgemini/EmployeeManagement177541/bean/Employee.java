package com.capgemini.EmployeeManagement177541.bean;


/**
 * Entity or Bean Class Which is used for storing the user input into an Object and Sending it to the JpaRepository methods
 */
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement //Mark this class for XML conversion
@Entity
@Table(name="cust")
public class Employee {
	
	@Id
	@Column(name="custid")
	private String custid;
	
	@Column(name="custname",length=30)
	private String custname;
	
	
	@Column(name="email",length=30)
	private String email;


	public String getCustid() {
		return custid;
	}


	public void setCustid(String custid) {
		this.custid = custid;
	}


	public String getName() {
		return custname;
	}


	public void setName(String name) {
		this.custname = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "Employee [custid=" + custid + ", name=" + custname + ", email=" + email + "]";
	}
	
	
	
	
}
