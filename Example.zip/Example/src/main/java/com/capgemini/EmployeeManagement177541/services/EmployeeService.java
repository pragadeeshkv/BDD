package com.capgemini.EmployeeManagement177541.services;

import java.util.List;

import com.capgemini.EmployeeManagement177541.bean.Employee;


/*
 * Interface of EmployeeService
 * methods used on employee table
 */
public interface EmployeeService {

	
	List<Employee> viewAllEmps();

	Employee viewById(String id);
}
