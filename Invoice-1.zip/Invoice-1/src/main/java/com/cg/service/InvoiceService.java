package com.cg.service;

import java.util.Date;
import java.util.List;

import com.cg.model.Invoice;

public interface InvoiceService {

	public boolean generateInvoice(Invoice invoice);
	public Invoice getInvoiceFromOrderId(int OrderId);
	public List<Invoice> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate);
	

}