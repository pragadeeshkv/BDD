package com.cg.service;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;



public interface IOrderService {


	public Order findOrderById(int orderId);
	
	
	
}