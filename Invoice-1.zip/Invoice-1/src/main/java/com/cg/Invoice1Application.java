package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Invoice1Application {

	public static void main(String[] args) {
		SpringApplication.run(Invoice1Application.class, args);
	}

}
